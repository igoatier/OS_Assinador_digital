ALTER TABLE clientes ADD asaas_id varchar(255) NULL;
ALTER TABLE cobrancas MODIFY COLUMN charge_id VARCHAR(255) NOT NULL;
