<?php
/* tradução: ferreiramauricio.com */

$lang['migration_none_found']           = "Nenhuma migração foi encontrada.";
$lang['migration_not_found']            = "Esta migração não pode ser encontrada.";
$lang['migration_multiple_version']         = "Esta são as multiplas migrações com o mesmo número de versão: %d.";
$lang['migration_class_doesnt_exist']   = "A classe de migração \"%s\" não pode ser encontrada.";
$lang['migration_missing_up_method']    = "A classe de migração \"%s\" está faltando o método 'up'.";
$lang['migration_missing_down_method']  = "A classe de migração \"%s\" está falntando o método 'down'.";
$lang['migration_invalid_filename']         = "Migração \"%s\" tem nome de arquivo inválido.";


/* End of file migration_lang.php */
/* Location: ./system/language/pt-br/migration_lang.php */
